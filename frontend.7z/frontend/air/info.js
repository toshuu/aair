var uname= 'Saurabh';
var ushop= 'Hub mall';
var uwano= '8668752540';
var umail= 'ye9te12@gmail.com';
var usubscription= 'Last Paid : No Records';
var ustatus= 'Connection Active.';
var uvideo = '<p>How to jump 4X growth?</p>';
var biturl = 'http://hub99.netlify.com';
var blogurl = 'v2asa';
var apptitle = 'Hub Mall';
var urange0to10 = '0';
var urange10to30 = '10';
var urange30to60 = '20';
var urange60to100 = '30';
var urange100to200 = '40';
var urange200to300 = '50';
var urange300to400 = '100';
var urange400to500 = '1000';
var urange500to1000 = '10000';
var urange1000to2000 = '2000';
var urange2000to3000 = '2000';


//** rgu11050@awsoo.com  hge39380@nbzmr.com  https://usebasin.com/f/8d0f21ebc6e8  **//